Carpeta en donde se almacenarán los comprobantes certificados.
